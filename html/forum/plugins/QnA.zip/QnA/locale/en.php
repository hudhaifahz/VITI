<?php if (!defined('APPLICATION')) exit();

// Discussion / Question
$Definition['Activity.QuestionAnswer.FullHeadline'] = '%1$s answered %4$s %8$s.';
$Definition['Activity.AnswerAccepted.FullHeadline'] = '%1$s accepted %4$s %8$s.';
$Definition['Q&A Accepted'] = 'Answered ✓';
$Definition['QnA Accepted Answer'] = 'Answer ✓';