<?php if (!defined('APPLICATION')) exit();
/**
 * Conversations default locale.
 *
 * @copyright 2009-2016 Vanilla Forums Inc.
 * @license http://www.opensource.org/licenses/gpl-2.0.php GNU GPL v2
 * @package Conversations
 * @since 2.0
 */

$Definition['RecipientUserID'] = 'recipient';


// Deprecated Translations
$Definition['Start a New Conversation'] = 'New Message';
$Definition['New Conversation'] = 'New Message';
$Definition['Start Conversation'] = 'Post Message';

