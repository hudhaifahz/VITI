<?php if (!defined('APPLICATION')) exit(); ?>
<h1><?php echo t("Activity Deleted") ?></h1>
<div class="Info">
    <?php echo t('Activity was successfully deleted.'); ?>
</div>