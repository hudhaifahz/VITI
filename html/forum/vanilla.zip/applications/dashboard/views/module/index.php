<?php if (!defined('APPLICATION')) exit();
$this->data('_Module')->render();
